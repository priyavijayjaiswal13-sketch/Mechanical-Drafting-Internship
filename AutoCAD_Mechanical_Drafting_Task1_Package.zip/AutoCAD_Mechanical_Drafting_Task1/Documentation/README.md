# AutoCAD Mechanical Drafting Internship — Task 1

Student: Priya Vijay Jaiswal  
Institute: Jawaharlal Darda Institute of Engineering and Technology, Yavatmal

## Contents
- `DXF_Drawings/`: editable DXF practice drawings for Washer, Shaft, Spacer, Mounting Plate, Bracket, and a bracket views sheet.
- `PDF_Drawings/`: printable PDF drawing sheets.
- `Documentation/Drafting_Report.pdf`: drafting report.
- `Documentation/Daily_Progress_Log.csv`: progress log.
- `Documentation/README.md`: this file.

## Important dimension note
The provided Task-1 brief lists the required components and deliverables but does not specify exact dimensions or manufacturing tolerances for every part. Dimensions in this practice set are illustrative assumptions for learning and must be checked with the internship mentor/official reference before being represented as final manufacturing dimensions.

## Mobile use
Open the ZIP in Android Files/Downloads and extract it. Open DXF files with a compatible CAD app. To submit to GitHub, open your existing repository `AutoCAD-Mechanical-Drafting-Task-1`, choose Add file / Upload files, select the extracted files, and commit the changes. If GitHub mobile does not show Upload files, use the browser's desktop-site option.

## Included components
1. Washer — OD 20 mm, ID 10 mm (thickness note 3 mm)
2. Shaft — length 60 mm, diameter 12 mm
3. Spacer — OD 24 mm, ID 10 mm (length note 15 mm)
4. Mounting Plate — 80 x 50 x 6 mm, four DIA 7 mm holes
5. Mounting Bracket — schematic L-bracket with base holes and upright hole
6. Bracket orthographic and schematic isometric views

## Verification checklist
- [ ] Confirm dimensions and projection method with mentor
- [ ] Open each DXF in AutoCAD or compatible CAD software
- [ ] Review dimensions, line types, layers, and title block requirements
- [ ] Export final checked drawings to DWG/PDF if required by the internship
- [ ] Upload drawing files, report, README, and progress log to GitHub
