SUBMISSION-STYLE PRACTICE SET
Files included:
- Mechanical_Drafting_Drawing_Set.pdf (5-sheet PDF)
- 01_Washer.dxf
- 02_Shaft.dxf
- 03_Spacer.dxf
- 04_Mounting_Plate.dxf
- 05_Mounting_Bracket.dxf
- Drafting_Report_Template.pdf
- Daily_Progress_Log.txt

Important: This is a practice set based on the component names and project type available in the task summary. Exact official dimensions/tolerances were not available here. Verify against the internship instructions before submitting. DXF is not native DWG. Do not claim a progress log entry unless you actually did the work.
